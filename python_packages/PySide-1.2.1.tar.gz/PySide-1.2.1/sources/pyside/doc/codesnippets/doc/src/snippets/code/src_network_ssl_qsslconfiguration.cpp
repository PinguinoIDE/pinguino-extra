//! [0]
config = sslSocket.sslConfiguration()
config.setProtocol(QSsl.TlsV1)
sslSocket.setSslConfiguration(config)
//! [0]
