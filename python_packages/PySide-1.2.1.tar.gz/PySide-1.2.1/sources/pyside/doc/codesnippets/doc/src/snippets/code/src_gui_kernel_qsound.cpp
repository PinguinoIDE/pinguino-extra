//! [0]
QSound.play("mysounds/bells.wav")
//! [0]


//! [1]
bells = QSound("mysounds/bells.wav")
bells.play()
//! [1]
