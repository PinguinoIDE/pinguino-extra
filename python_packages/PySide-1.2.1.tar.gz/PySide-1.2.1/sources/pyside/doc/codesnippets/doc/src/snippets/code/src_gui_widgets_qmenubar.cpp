//! [0]
menubar.addMenu(fileMenu)
//! [0]


//! [1]
menuBar = QMenuBar()
//! [1]
