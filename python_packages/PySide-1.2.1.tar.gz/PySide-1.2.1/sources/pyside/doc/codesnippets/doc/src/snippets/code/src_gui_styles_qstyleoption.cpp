//! [0]
def styleHint(self, stylehint, opt, widget, returnData):
    if stylehint == SH_RubberBand_Mask:
        if isinstance(QStyleHintReturnMask, hint):
            ...
    ...
//! [0]
