//! [0]
        writer = QTextDocumentWriter()
        writer.setFormat("odf") # same as writer.setFormat("ODF");
//! [0]

