//! [0]
class MainWindow(...):
    def __init__(self):
        self.workspace = QWorkspace()
        self.setCentralWidget(workspace)
        ...
//! [0]
