//! [0]
selection = QItemSelection(topLeft, bottomRight)
//! [0]


//! [1]
selection = QItemSelection()
...
selection.select(topLeft, bottomRight)
//! [1]
