//! [0]
backaction.setToolTip(browser.historyTitle(-1))
forwardaction.setToolTip(browser.historyTitle(+1))
//! [0]
