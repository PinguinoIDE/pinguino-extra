//! [0]
def heightForWidth(self, w):
    if cache_dirty or cached_width != w:
        h = calculateHeightForWidth(w)
        self.cached_hfw = h
        return h
    return cached_hfw
//! [0]
