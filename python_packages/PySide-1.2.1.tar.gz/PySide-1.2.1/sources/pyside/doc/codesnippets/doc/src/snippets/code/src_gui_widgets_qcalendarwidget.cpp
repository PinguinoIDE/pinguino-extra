//! [0]
calendar.setGridVisible(True)
//! [0]


//! [1]
calendar.setGridVisible(True)
calendar.setMinimumDate(QDate(2006, 6, 19))
//! [1]


//! [2]
calendar.setGridVisible(True)
calendar.setMaximumDate(QDate(2006, 7, 3))
//! [2]


//! [3]

calendar.setDateRange(min, max)
//! [3]


//! [4]

calendar.setMinimumDate(min)
calendar.setMaximumDate(max)
//! [4]


//! [5]
calendar.setGridVisible(True)
//! [5]
