//! [0]
printDialog = QPrintDialog(printer, parent)
if printDialog.exec_() == QDialog.Accepted:
    # print ...
//! [0]
