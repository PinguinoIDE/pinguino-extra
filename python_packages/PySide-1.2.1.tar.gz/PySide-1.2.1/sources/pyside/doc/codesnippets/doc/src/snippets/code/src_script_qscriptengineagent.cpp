//! [0]
var a = Math.random() + 2;
//! [0]


//! [1]
function cube(a) {
    return a * a * a;
}

var a = cube(3);
//! [1]
