//! [0]
server.setProxy(QNetworkProxy.NoProxy)
//! [0]
