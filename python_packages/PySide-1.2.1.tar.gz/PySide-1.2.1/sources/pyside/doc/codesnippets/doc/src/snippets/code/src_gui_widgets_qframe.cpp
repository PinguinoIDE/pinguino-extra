//! [0]
label = QLabel()
label.setFrameStyle(QFrame.Panel | QFrame.Raised)
label.setLineWidth(2)

pbar = QProgressBar()
label.setFrameStyle(QFrame.NoFrame)
//! [0]
