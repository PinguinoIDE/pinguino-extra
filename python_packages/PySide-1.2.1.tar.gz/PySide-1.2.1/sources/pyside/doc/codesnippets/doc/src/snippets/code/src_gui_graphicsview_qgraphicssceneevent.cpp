//! [0]

setDropAction(proposedAction())

//! [0]
