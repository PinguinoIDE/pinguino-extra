//! [0]
setCellWidget(index, QLineEdit())
...
setCellWidget(index, QTextEdit())
//! [0]
